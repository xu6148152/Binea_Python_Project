# -*- encoding: utf-8 -*-

def bar():
    print('bar')