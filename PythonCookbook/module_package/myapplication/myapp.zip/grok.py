# -*- encoding: utf-8 -*-

def grok():
    print('grok')