# -*- encoding: utf-8 -*-

def spam():
    print('spam')