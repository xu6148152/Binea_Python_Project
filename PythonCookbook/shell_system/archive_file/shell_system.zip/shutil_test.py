#!/usr/bin/env python3
# -*- encoding: utf-8 -*-

import shutil

# shutil.copy(src, dst)
# shutil.copy2(src, dst)
# shutil.move(src, dst)
# shutil.copytree()

shutil.make_archive('shell_system', 'zip', '.')