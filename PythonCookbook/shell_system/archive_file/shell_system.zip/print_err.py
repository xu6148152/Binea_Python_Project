#!/usr/bin/env python3
# -*- encoding: utf-8 -*-

import sys

sys.stderr.write('It failed!\n')
raise SystemExit(1)
